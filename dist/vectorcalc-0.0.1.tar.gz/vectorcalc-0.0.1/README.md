# Vectorcalc

A simple package to perform elementary operations in vector calculus.

## Features

 - Numerical line integrals 
